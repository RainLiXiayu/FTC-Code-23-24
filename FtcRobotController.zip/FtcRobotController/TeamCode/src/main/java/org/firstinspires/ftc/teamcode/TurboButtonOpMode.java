package org.firstinspires.ftc.teamcode;


import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.Gamepad;

@TeleOp
public class TurboButtonOpMode extends LinearOpMode {

    @Override
    public void runOpMode() {
        Gamepad gamepad1 = new Gamepad();

        waitForStart();

        while (opModeIsActive()) {
            // Check if gamepad1.a is pressed
            boolean isTurboButtonPressed = gamepad1.a;

            // Gets the joystick input value
            double joystickX = gamepad1.left_stick_x;
            double joystickY = gamepad1.left_stick_y;

            // Apply turbo button functionality
            double multiplier = isTurboButtonPressed ? 1.0 : 0.5;
            double modifiedJoystickX = joystickX * multiplier;
            double modifiedJoystickY = joystickY * multiplier;

            // Calculate forward speed
            double forwardSpeed = Math.sqrt(modifiedJoystickX
                    * modifiedJoystickX + modifiedJoystickY * modifiedJoystickY);

            // Report forward speed
            telemetry.addData("Forward speed", forwardSpeed);
            telemetry.update();

        }
    }
}

