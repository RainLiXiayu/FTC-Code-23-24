package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.util.ElapsedTime;

@TeleOp(name="Motor Test", group="Linear Opmode")
public class MotorTest extends LinearOpMode {
    private ElapsedTime runtime = new ElapsedTime();
    private DcMotor testMotor = null;

    @Override
    public void runOpMode(){
        testMotor = hardwareMap.get(DcMotor.class, "test motor");
        waitForStart();
        runtime.reset();
        while(opModeIsActive()){
            if(gamepad1.a){
                testMotor.setPower(1.0);
            }else{
                testMotor.setPower(0.0);
            }
        }
    }
}
