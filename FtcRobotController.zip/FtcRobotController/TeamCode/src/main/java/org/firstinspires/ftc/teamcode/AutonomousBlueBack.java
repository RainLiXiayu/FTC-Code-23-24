package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import org.firstinspires.ftc.teamcode.drive.SampleMecanumDrive;
import org.firstinspires.ftc.teamcode.trajectorysequence.TrajectorySequence;
import com.acmerobotics.roadrunner.geometry.Pose2d;
import com.qualcomm.robotcore.hardware.ColorSensor;
import com.qualcomm.robotcore.hardware.Servo;

@Autonomous
public class AutonomousBlueBack extends LinearOpMode {
    private SampleMecanumDrive drive;
    private ColorSensor colorSensorLeft;
    private ColorSensor colorSensorRight;
    Servo DroneLauncher;
    private Servo launcherServo;
    @Override
    public void runOpMode() {
        PbClaw pbGrab = new PbClaw();
        pbGrab.init(hardwareMap);
        DroneLauncher = hardwareMap.servo.get("Launcher Servo");
        DroneLauncher.setPosition(0.4);
        drive = new SampleMecanumDrive(hardwareMap);
        colorSensorLeft = hardwareMap.colorSensor.get("color sensor left");
        colorSensorRight = hardwareMap.colorSensor.get("color sensor right");

        TrajectorySequence traj1 = drive.trajectorySequenceBuilder(new Pose2d(-35, 63, Math.toRadians(-90)))
                .splineToSplineHeading(new Pose2d(-35, 35, Math.toRadians(-90)), Math.toRadians(-90))
                .build();

        TrajectorySequence traj2 = drive.trajectorySequenceBuilder(new Pose2d(-35, 35, Math.toRadians(90)))
                .splineToSplineHeading(new Pose2d(-20,0.0, Math.toRadians(0)), Math.toRadians(0))
                .splineToSplineHeading(new Pose2d(0,0,Math.toRadians(0)),Math.toRadians(0))
                .splineToSplineHeading(new Pose2d(47.6, 35.2, Math.toRadians(0)), Math.toRadians(0))
                .strafeLeft(20)
                .build();


        waitForStart();
        pbGrab.ClawOpen();

        int colorValueLeft = colorSensorLeft.argb();
        int colorValueRight = colorSensorRight.argb();

        pbGrab.ClawClose();
        sleep(2000);
        pbGrab.RotatePlace();

        // First detection
        drive.followTrajectorySequenceAsync(traj1);
        drive.waitForIdle();

        // Left turn
        drive.turn(Math.toRadians(90));
        colorValueLeft = colorSensorLeft.argb();
        colorValueRight = colorSensorRight.argb();
        telemetry.addData("Red left : ",  colorSensorLeft.argb());
        telemetry.addData("Red right : ",  colorSensorRight.argb());
        telemetry.update();
        if (colorValueLeft > 60 || colorValueRight > 60) {
            pbGrab.RotateGrab();
            pbGrab.ClawOpen();
            pbGrab.RotatePlace();
            drive.turn(Math.toRadians(-90)); // back to middle
            traj2 = drive.trajectorySequenceBuilder(new Pose2d(-35, 35, Math.toRadians(90)))
                    .splineToSplineHeading(new Pose2d(-20,0.0, Math.toRadians(0)), Math.toRadians(0))
                    .splineToSplineHeading(new Pose2d(0,0,Math.toRadians(0)),Math.toRadians(0))
                    .splineToSplineHeading(new Pose2d(47.6, 35.2, Math.toRadians(0)), Math.toRadians(0))
                    .strafeLeft(20)
                    .build();
        } else {
            // Middle turn
            drive.turn(Math.toRadians(-90));
            colorValueLeft = colorSensorLeft.argb();
            colorValueRight = colorSensorRight.argb();
            telemetry.addData("Red left : ",  colorSensorLeft.argb());
            telemetry.addData("Red right : ",  colorSensorRight.argb());
            telemetry.update();
            if (colorValueLeft > 60 || colorValueRight > 60) {
                pbGrab.RotateGrab();
                pbGrab.ClawOpen();
                pbGrab.RotatePlace();
                traj2 = drive.trajectorySequenceBuilder(new Pose2d(-35, 35, Math.toRadians(90)))
                        .splineToSplineHeading(new Pose2d(-20,0.0, Math.toRadians(0)), Math.toRadians(0))
                        .splineToSplineHeading(new Pose2d(0,0,Math.toRadians(0)),Math.toRadians(0))
                        .splineToSplineHeading(new Pose2d(47.6, 35.2, Math.toRadians(0)), Math.toRadians(0))
                        .strafeLeft(20)
                        .build();
            } else {
                // Right turn
                drive.turn(Math.toRadians(-90));
                pbGrab.ClawOpen();
                pbGrab.RotatePlace();
                drive.turn(Math.toRadians(90));
                traj2 = drive.trajectorySequenceBuilder(new Pose2d(-35, 35, Math.toRadians(90)))
                        .splineToSplineHeading(new Pose2d(-20,0.0, Math.toRadians(0)), Math.toRadians(0))
                        .splineToSplineHeading(new Pose2d(0,0,Math.toRadians(0)),Math.toRadians(0))
                        .splineToSplineHeading(new Pose2d(47.6, 35.2, Math.toRadians(0)), Math.toRadians(0))
                        .strafeLeft(20)
                        .build();
            }
        }
        drive.followTrajectorySequenceAsync(traj2);
        drive.waitForIdle();

        telemetry.addData("Red left : ",  colorSensorLeft.argb());
        telemetry.addData("Red right : ",  colorSensorRight.argb());
        telemetry.update();
    }
}

