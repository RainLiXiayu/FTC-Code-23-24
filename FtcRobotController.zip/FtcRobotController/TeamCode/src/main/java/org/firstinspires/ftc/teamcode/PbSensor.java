package org.firstinspires.ftc.teamcode;

import com.acmerobotics.dashboard.config.Config;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.hardware.ColorSensor;
import com.qualcomm.robotcore.util.ElapsedTime;

@Config
@Autonomous
public class PbSensor extends LinearOpMode {
    private ElapsedTime runtime = new ElapsedTime();
    private ColorSensor colorSensor;
    public static int redValue = 30;
    public static int blueValue = 30;

    @Override
    public void runOpMode() {
        telemetry.addData("Status", "Initialized");
        telemetry.update();

        // Initialize sensors
        colorSensor = hardwareMap.colorSensor.get("color sensor");
        waitForStart();

        // Run until the end of the match (driver presses STOP)
        while (opModeIsActive()) {
            telemetry.addData("color sensor", colorSensor.getDeviceName());

            // Rev2mDistanceSensor specific methods
            telemetry.addData("Detected Color (R,B)", "(" + colorSensor.red() + ", " + colorSensor.blue() + ")");
            telemetry.update();

            // Example condition to control motors based on color sensor or distance sensor
            // For example, if the color sensor detects a specific color:
            if (colorSensor.red() > redValue) {
                telemetry.addData("Status", "Red");
            } else if (colorSensor.blue() > blueValue) {
                telemetry.addData("Status", "Blue");
            }
        }
    }
}
