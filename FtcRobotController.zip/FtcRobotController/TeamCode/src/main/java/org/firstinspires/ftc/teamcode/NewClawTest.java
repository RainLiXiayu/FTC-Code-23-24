package org.firstinspires.ftc.teamcode;

import com.acmerobotics.dashboard.config.Config;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.Servo;

@Config
@TeleOp
public class NewClawTest extends OpMode{
    public static double initialServoPositionClaw = 0.33333;
    public static double closeclawposition = 0.65;
    public static double initialServoPositionRotate = 0.5;
    public static double rotateplaceposition = 0.749;

    double ServoPositionClaw;
    double ServoPositionRotate;
    //

    public static double ActualClawSpeedIncrement = 0.007;
    public static double ActualRotateSpeedIncrement = 0.007;

    double clawSpeedIncrement = 0;
    double rotateSpeedIncrement = 0;

    Servo ClawServo;  // LEFT
    Servo RotateServo; //RIGHT
    //

    boolean leftTriggerPressed;
    boolean leftBumperPressed;
    boolean rightTriggerPressed;
    boolean rightBumperPressed;
    //



    @Override
    public void init() {
        ClawServo = hardwareMap.get(Servo.class, "left servo");
        RotateServo = hardwareMap.get(Servo.class, "right servo");
        ClawServo.setPosition(initialServoPositionClaw);
        RotateServo.setPosition(initialServoPositionRotate);

        leftTriggerPressed = false;
        leftBumperPressed = false;
        rightTriggerPressed = false;
        rightBumperPressed = false;
    }

    public void start() {
        ClawServo.setPosition(initialServoPositionClaw); //0.3333333
        RotateServo.setPosition(initialServoPositionRotate); //0.5
    }

    @Override
    public void loop() {

        //CLAW - LEFT
        if(gamepad1.left_trigger>0.5){
            if(!leftTriggerPressed){
                clawSpeedIncrement = ActualClawSpeedIncrement;
            }
            leftTriggerPressed = true;
        }else{
            if(leftTriggerPressed){
                clawSpeedIncrement = 0.0;
            }
            leftTriggerPressed = false;
        }

        if(gamepad1.left_bumper){
            if(!leftBumperPressed){
                clawSpeedIncrement = -ActualClawSpeedIncrement;
            }
            leftBumperPressed = true;
        }else{
            if(leftBumperPressed){
                leftBumperPressed = false;
            }
        }

        ServoPositionClaw += clawSpeedIncrement;
        ServoPositionClaw = Math.min(closeclawposition //0.65
                ,Math.max(initialServoPositionClaw, ServoPositionClaw)); //0.33333
        ClawServo.setPosition(ServoPositionClaw);



        //Rotate - RIGHT

        if(gamepad1.right_trigger>0.5){
            if(!rightTriggerPressed){
                rotateSpeedIncrement = -ActualRotateSpeedIncrement;
            }
            rightTriggerPressed=true;
        }else{
            if(rightTriggerPressed){
                rotateSpeedIncrement = 0.0;
            }
            rightTriggerPressed=false;
        }

        if(gamepad1.right_bumper){
            if(!rightBumperPressed){
                rotateSpeedIncrement = ActualRotateSpeedIncrement;
            }
            rightBumperPressed=true;
        }else{
            if(rightBumperPressed){
                rightBumperPressed = false;
            }
        }

        ServoPositionRotate += rotateSpeedIncrement;
        ServoPositionRotate = Math.min(rotateplaceposition //0.749
                ,Math.max(initialServoPositionRotate, ServoPositionRotate)); //0.5
        RotateServo.setPosition(ServoPositionRotate);

        telemetry.addData("Rotate Servo position", ServoPositionRotate);
        telemetry.addData("Claw Servo position", ServoPositionClaw);

    }

}
