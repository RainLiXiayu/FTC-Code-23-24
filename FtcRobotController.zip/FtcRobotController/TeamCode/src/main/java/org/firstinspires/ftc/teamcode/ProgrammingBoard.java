package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.TouchSensor;

public class ProgrammingBoard {

    private DcMotor leftMotor;
    private DcMotor rightMotor;
    private TouchSensor touchSensor;


    public void init(HardwareMap hardwareMap) {

        leftMotor = hardwareMap.get(DcMotor.class, "left_motor");
        leftMotor.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);


        rightMotor = hardwareMap.get(DcMotor.class, "right_motor");
        rightMotor.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);


        touchSensor = hardwareMap.get(TouchSensor.class, "touch_sensor");
    }


    public void moveForward(double power) {
        leftMotor.setPower(power);
        rightMotor.setPower(power);
    }


    public void stopMotors() {
        leftMotor.setPower(0);
        rightMotor.setPower(0);
    }


    public boolean isTouchSensorPressed() {
        return touchSensor.isPressed();
    }
}
