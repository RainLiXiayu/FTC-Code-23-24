package org.firstinspires.ftc.teamcode;

import com.qualcomm.hardware.rev.RevHubOrientationOnRobot;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.IMU;
import com.qualcomm.robotcore.util.ElapsedTime;

@Autonomous(name = "SpinTest" ,group = "Autonomous")
public class SpinTest extends LinearOpMode {
        private ElapsedTime runtime = new ElapsedTime();
        private DcMotor frontLeftmotor;
        private DcMotor frontRightmotor;
        private DcMotor backLeftmotor;
        private DcMotor backRightmotor;
        @Override
        public void runOpMode() throws InterruptedException {

                DcMotor frontLeftMotor = hardwareMap.dcMotor.get("frontLeftMotor");
                DcMotor backLeftMotor = hardwareMap.dcMotor.get("backLeftMotor");
                DcMotor frontRightMotor = hardwareMap.dcMotor.get("frontRightMotor");
                DcMotor backRightMotor = hardwareMap.dcMotor.get("backRightMotor");

                DcMotor viperslide = hardwareMap.dcMotor.get("viperslide");

                frontLeftMotor.setDirection(DcMotorSimple.Direction.REVERSE);
                backLeftMotor.setDirection(DcMotorSimple.Direction.REVERSE);


                waitForStart();
                runtime.reset();
                while (opModeIsActive() && (runtime.seconds() == 3.0)) {
                        frontLeftMotor.setPower(0.5);
                        frontRightMotor.setPower(-0.5);
                        backLeftMotor.setPower(0.5);
                        backRightMotor.setPower(-0.5);
                }
        }

}

