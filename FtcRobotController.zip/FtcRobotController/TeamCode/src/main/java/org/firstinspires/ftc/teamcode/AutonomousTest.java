package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;

import org.firstinspires.ftc.teamcode.drive.SampleMecanumDrive;
import org.firstinspires.ftc.teamcode.trajectorysequence.TrajectorySequence;

import com.acmerobotics.roadrunner.geometry.Pose2d;

@Autonomous
public class AutonomousTest extends LinearOpMode {
    private SampleMecanumDrive drive;

    @Override
    public void runOpMode() {

        drive = new SampleMecanumDrive(hardwareMap);

        TrajectorySequence traj1 =  drive.trajectorySequenceBuilder(new Pose2d(-35, -62, Math.toRadians(90)))
                .splineToSplineHeading(new Pose2d(-35, -35.2, Math.toRadians(90)), Math.toRadians(90))
                .turn(Math.toRadians(90))//left
                .turn(Math.toRadians(-90))//middle
                .turn(Math.toRadians(-90))//right
                .turn(Math.toRadians(90))//back to middle
                .splineToSplineHeading(new Pose2d(0, 0, Math.toRadians(0)), Math.toRadians(0))
                .splineToSplineHeading(new Pose2d(20, 0, Math.toRadians(0)), Math.toRadians(0))
                .splineToSplineHeading(new Pose2d(47.6, -35.2, Math.toRadians(0)), Math.toRadians(0))
                .strafeRight(20)
                .build();
        waitForStart();
        drive.followTrajectorySequence(traj1);
    }

}



