package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;

@TeleOp(name = "TestMotor", group = "TeleOp")
public class TestMotor extends OpMode {

    private DcMotor motor;
    private static final double MOTOR_POWER = 0.5;

    @Override
    public void init() {
        motor = hardwareMap.get(DcMotor.class, "test motor");
    }

    @Override
    public void loop() {
        motor.setPower(MOTOR_POWER);
        telemetry.addData("Motor Power", motor.getPower());
        telemetry.update();
    }

}
