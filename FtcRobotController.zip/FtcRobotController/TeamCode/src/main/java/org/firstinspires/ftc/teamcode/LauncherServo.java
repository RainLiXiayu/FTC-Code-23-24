package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Gamepad;

@TeleOp(name = "Launcher", group = "TeleOp")
public class LauncherServo extends OpMode {

    private Servo launcherServo;

    @Override
    public void init() {
        launcherServo = hardwareMap.get(Servo.class, "Launcher Servo");
    }

    @Override
    public void loop() {
        // Check if the back button on gamepad2 is pressed
        if (gamepad2.back) {
            // Rotate the servo from 90 to 180 degrees
            launcherServo.setPosition(1.0);
        } else {
            launcherServo.setPosition(0.4);
        }
    }
}
