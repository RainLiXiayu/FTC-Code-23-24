package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.Servo;

@TeleOp(name = "CombinedServoControlOpMode", group = "TeleOp")
public class CombinedServoControlOpMode extends OpMode {

    private Servo leftServo;
    private Servo rightServo;
    private boolean leftTriggerPressed;
    private boolean leftBumperPressed;
    private double leftServoPosition = 0.31; // not grab
    private boolean rightTriggerPressed;
    private boolean rightBumperPressed;
    private double rightServoPosition = 0.45;// not grab
    private double leftSpeedIncrement = 0.01;
    private double rightSpeedIncrement = 0.01;

    public void init() {
        leftServo = hardwareMap.servo.get("left servo");
        rightServo = hardwareMap.servo.get("right servo");
        leftTriggerPressed = false;
        leftBumperPressed = false;
        rightTriggerPressed = false;
        rightBumperPressed = false;
        rightServoPosition = rightServo.getPosition();
        leftServoPosition = leftServo.getPosition();
        if (gamepad1 != null) {
            telemetry.addData("Status", "Gamepad1 connected");
        } else {
            telemetry.addData("Status", "Gamepad1 not connected");
        }
    }

    public void start() {
        leftServo.setPosition(0.31);
        rightServo.setPosition(0.45);
    }

    @Override
    public void loop() {
        if (gamepad1.left_trigger > 0.5) {
            if (!leftTriggerPressed) {
                leftSpeedIncrement = 0.01;
            }
            leftTriggerPressed = true;
        } else {
            if (leftTriggerPressed) {
                leftTriggerPressed = false;
            }
        }

        if (gamepad1.left_bumper) {
            if (!leftBumperPressed) {
                leftSpeedIncrement = -0.01;
            }
            leftBumperPressed = true;
        } else {
            if (leftBumperPressed) {
                leftBumperPressed = false;
            }
        }

        leftServoPosition += leftSpeedIncrement;
        leftServoPosition = Math.min(1.0, Math.max(0.0, leftServoPosition));
        leftServo.setPosition(leftServoPosition);

        if (gamepad1.right_trigger > 0.5) {
            if (!rightTriggerPressed) {
                rightSpeedIncrement = 0.01;
            }
            rightTriggerPressed = true;
        } else {
            if (rightTriggerPressed) {
                rightTriggerPressed = false;
            }
        }

        if (gamepad1.right_bumper) {
            if (!rightBumperPressed) {
                rightSpeedIncrement = -0.01;
            }
            rightBumperPressed = true;
        } else {
            if (rightBumperPressed) {
                rightBumperPressed = false;
            }
        }

        rightServoPosition += rightSpeedIncrement;
        rightServoPosition = Math.min(1.0, Math.max(0.0, rightServoPosition));
        rightServo.setPosition(rightServoPosition);

        telemetry.addData("Left Servo Position", leftServoPosition);
        telemetry.addData("Right Servo Position", rightServoPosition);
        telemetry.addData("Left Servo Power", leftSpeedIncrement);
        telemetry.update();

    }
}

