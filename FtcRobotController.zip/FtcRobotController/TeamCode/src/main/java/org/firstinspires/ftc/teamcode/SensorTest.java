package org.firstinspires.ftc.teamcode;

import com.acmerobotics.dashboard.config.Config;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.hardware.ColorSensor;
import com.qualcomm.robotcore.hardware.DistanceSensor;
import com.qualcomm.robotcore.util.ElapsedTime;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;

@Config
@Autonomous
public class SensorTest extends LinearOpMode {

    private ElapsedTime runtime = new ElapsedTime();

    private ColorSensor ColorSensor;

    public  static int redvalue = 30;
    public static int bluevalue =30;

    @Override
    public void runOpMode() {


        telemetry.addData("Status", "Initialized");
        telemetry.update();

        // Initialize sensors
        ColorSensor = hardwareMap.colorSensor.get("color sensor");

        waitForStart();

        // Run until the end of the match (driver presses STOP)
        while (opModeIsActive()) {


            telemetry.addData("color sensor", ColorSensor.getDeviceName());

            // Rev2mDistanceSensor specific methods
            telemetry.addData("Detected Color (R,B)", "(" + ColorSensor.red() + ", " + ColorSensor.blue() + ")");
            telemetry.update();


            // Example condition to control motors based on color sensor or distance sensor
            // For example, if the color sensor detects a specific color:
            if (ColorSensor.red() > redvalue) {
                telemetry.addData("Status", "Red");
           } else if (ColorSensor.blue() > bluevalue) {
                telemetry.addData("Status", "Blue");
            }
            }
        }
    }